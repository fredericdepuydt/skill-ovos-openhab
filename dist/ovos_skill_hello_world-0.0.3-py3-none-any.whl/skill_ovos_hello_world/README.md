# <img src='https://raw.githack.com/FortAwesome/Font-Awesome/master/svgs/solid/smile.svg' card_color='#22a7f0' width='50' height='50' style='vertical-align:bottom'/> Hello World
Introductory Skill so that Skill Authors can see how a Mycroft Skill is put together

## About
This is a basic Hello Word Skill that takes an _Utterance_ from the user and provides a voice response - a _Dialog_. This Skill demonstrates the basic directory and file structure of a Mycroft Skill, and is a good first Skill to study if you are interested in developing Skills for the Mycroft ecosystem.

## Examples
* "Hello world"
* "How are you?"
* "Thank you"

## Credits
Mycroft AI (@MycroftAI)

## Category
**Configuration**

## Tags
#helloworld
#first-skill
#hello
#greeting
